package myclasses;

public class CircuitBreakerException extends Exception {

}
