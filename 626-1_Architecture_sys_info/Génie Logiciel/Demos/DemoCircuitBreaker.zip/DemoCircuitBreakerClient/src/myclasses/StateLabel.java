package myclasses;

public enum StateLabel {
	open,closed
}



