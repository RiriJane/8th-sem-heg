public class Main {

    public static void main(String[] args) {
        chargerResultats();
        afficherPlusGrandeCommune();
        System.out.println("=========================================================================================");
        afficherParOrdreAlphabetique();
        System.out.println("=========================================================================================");
        afficherParParticipation();
    }

    /** Lit le fichier results.csv et le conserve en mémoire dans une Collection */
    private static void chargerResultats() {
    }

    /** Affiche le résultat de la plus grande commune (plus grand nombre d'électeurs) */
    private static void afficherPlusGrandeCommune() {
        System.out.println("Plus grande commune : ");
    }

    /** Affiche tous les résultats, triés par nom de commune */
    private static void afficherParOrdreAlphabetique() {
    }

    /** Affiche tous les résultats, triés du plus grand taux de participation au plus petit */
    private static void afficherParParticipation() {
    }
}