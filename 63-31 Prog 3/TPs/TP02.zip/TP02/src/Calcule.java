public abstract class Calcule<T> {

    public abstract T total();
    public abstract T moyenne();
}
