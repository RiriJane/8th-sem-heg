public interface Valorisable{
    public double getValue();
}
